/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVC;

/**
 *
 * @author AboodHassKov
 */
public interface view {
    public String show(String name, String address,
            String dateOfBirth, String accountNumber);
}
